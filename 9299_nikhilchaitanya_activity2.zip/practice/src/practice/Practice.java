package practice;

public class Practice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        
		System.out.println("Hello java");
		System.out.println(280620);
		System.out.println(5+5);
		String name = "nikhil chaitanya";
		System.out.println(name);
		int myNum = 15;
		System.out.println(myNum);
		String firstName = "nikhil  ";
		String lastName = "chaitanya";
		String fullName = firstName + lastName;
		System.out.println(fullName);
		
		
	}
	}


