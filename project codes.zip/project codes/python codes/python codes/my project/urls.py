
from django.conf.urls import url
from django.contrib import admin
from Remote_User import views as remoteuser
from bus_crowding import settings
from Service_Provider import views as serviceprovider
from django.conf.urls.static import static
from django.conf import settings


urlpatterns = [
    url('admin/', admin.site.urls),
    url(r'^$', remoteuser.login, name="login"),
    url(r'^Register1/$', remoteuser.Register1, name="Register1"),
    url(r'^Search_PassengerFlow_DataSets/$', remoteuser.Search_PassengerFlow_DataSets, name="Search_PassengerFlow_DataSets"),
url(r'^View_Bus_Capacity_DataSetDetails/$', remoteuser.View_Bus_Capacity_DataSetDetails, name="View_Bus_Capacity_DataSetDetails"),
    url(r'^ratings/(?P<pk>\d+)/$', remoteuser.ratings, name="ratings"),
    url(r'^ViewYourProfile/$', remoteuser.ViewYourProfile, name="ViewYourProfile"),
    url(r'^Add_DataSet_Details/$', serviceprovider.Add_DataSet_Details, name="Add_DataSet_Details"),

    url(r'^serviceproviderlogin/$',serviceprovider.serviceproviderlogin, name="serviceproviderlogin"),
    url(r'View_Remote_Users/$',serviceprovider.View_Remote_Users,name="View_Remote_Users"),
    url(r'^charts/(?P<chart_type>\w+)', serviceprovider.charts,name="charts"),
    url(r'^charts1/(?P<chart_type>\w+)', serviceprovider.charts1, name="charts1"),
    url(r'^likeschart/(?P<like_chart>\w+)', serviceprovider.likeschart, name="likeschart"),
    url(r'^Search_PassengerFlow_Details/$', serviceprovider.Search_PassengerFlow_Details, name="Search_PassengerFlow_Details"),

    url(r'^View_PassangerFlow_Prediction_Details/$', serviceprovider.View_PassangerFlow_Prediction_Details, name="View_PassangerFlow_Prediction_Details"),

    url(r'^View_PassangerFlow_Details/$', serviceprovider.View_PassangerFlow_Details, name="View_PassangerFlow_Details"),

    url(r'^View_Search_Ratio/$', serviceprovider.View_Search_Ratio, name="View_Search_Ratio"),



]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
