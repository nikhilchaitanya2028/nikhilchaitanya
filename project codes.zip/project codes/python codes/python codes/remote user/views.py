from django.db.models import Count
from django.db.models import Q
from django.shortcuts import render, redirect, get_object_or_404
import datetime
import openpyxl

import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error


# Create your views here.
from Remote_User.models import ClientRegister_Model,bus_crowding_model,bus_capacity_model,search_ratio_model


def login(request):


    if request.method == "POST" and 'submit1' in request.POST:

        username = request.POST.get('username')
        password = request.POST.get('password')
        try:

            enter = ClientRegister_Model.objects.get(username=username, password=password)
            request.session["userid"] = enter.id

            return redirect('Search_PassengerFlow_DataSets')
        except:
            pass

    return render(request,'RUser/login.html')

def Add_DataSet_Details(request):
    if "GET" == request.method:
        return render(request, 'RUser/Add_DataSet_Details.html', {})
    else:
        excel_file = request.FILES["excel_file"]

        wb = openpyxl.load_workbook(excel_file)

        # getting all sheets
        sheets = wb.sheetnames
        print(sheets)

        # getting a particular sheet
        worksheet = wb["Sheet1"]
        print(worksheet)

        # getting active sheet
        active_sheet = wb.active
        print(active_sheet)

        # reading a cell
        print(worksheet["A1"].value)

        excel_data = list()
        # iterating over the rows and
        # getting value from each cell in row
        for row in worksheet.iter_rows():
            row_data = list()
            for cell in row:
                row_data.append(str(cell.value))
                print(cell.value)
            excel_data.append(row_data)

            bus_capacity_model.objects.all().delete()
            bus_crowding_model.objects.all().delete()
            search_ratio_model.objects.all().delete()
    for r in range(1, active_sheet.max_row+1):
        bus_capacity_model.objects.create(
        names=active_sheet.cell(r, 1).value,
        Bus_Route=active_sheet.cell(r, 2).value,
        Bus_Name=active_sheet.cell(r, 3).value,
        Bus_Manufacturare=active_sheet.cell(r, 4).value,
        Bus_Type=active_sheet.cell(r, 5).value,
        day_1=active_sheet.cell(r, 6).value,
        day_2=active_sheet.cell(r, 7).value,
        day_3=active_sheet.cell(r, 8).value,
        day_4=active_sheet.cell(r, 9).value,
        day_5=active_sheet.cell(r, 10).value,
        day_6=active_sheet.cell(r, 11).value,
        day_7=active_sheet.cell(r, 12).value,
        day_8=active_sheet.cell(r, 13).value,
        day_9=active_sheet.cell(r, 14).value,
        day_10=active_sheet.cell(r, 15).value,
        day_11=active_sheet.cell(r, 16).value,
        day_12=active_sheet.cell(r, 17).value,
        day_13=active_sheet.cell(r, 18).value,
        day_14=active_sheet.cell(r, 19).value,
        day_15=active_sheet.cell(r, 20).value,
        day_16=active_sheet.cell(r, 21).value,
        day_17=active_sheet.cell(r, 22).value,
        day_18=active_sheet.cell(r, 23).value,
        day_19=active_sheet.cell(r, 24).value,
        day_20=active_sheet.cell(r, 25).value,
        day_21=active_sheet.cell(r, 26).value,
        day_22=active_sheet.cell(r, 27).value,
        day_23=active_sheet.cell(r, 28).value,
        day_24=active_sheet.cell(r, 29).value,
        day_25=active_sheet.cell(r, 30).value,
        day_26=active_sheet.cell(r, 31).value,
        day_27=active_sheet.cell(r, 32).value,
        day_28=active_sheet.cell(r, 33).value,
        day_29=active_sheet.cell(r, 34).value,
        day_30=active_sheet.cell(r, 35).value,
        day_31=active_sheet.cell(r, 36).value,
        day_32=active_sheet.cell(r, 37).value,
        day_33=active_sheet.cell(r, 38).value,
        day_34=active_sheet.cell(r, 39).value,
        day_35=active_sheet.cell(r, 40).value,
        day_36=active_sheet.cell(r, 41).value,
        day_37=active_sheet.cell(r, 42).value,
        day_38=active_sheet.cell(r, 43).value,
        day_39=active_sheet.cell(r, 44).value,
        day_40=active_sheet.cell(r, 45).value,
        day_41=active_sheet.cell(r, 46).value,
        day_42=active_sheet.cell(r, 47).value,
        day_43=active_sheet.cell(r, 48).value,
        day_44=active_sheet.cell(r, 49).value,
        day_45=active_sheet.cell(r, 50).value,
        day_46=active_sheet.cell(r, 51).value,
        day_47=active_sheet.cell(r, 52).value,
        day_48=active_sheet.cell(r, 53).value,
        day_49=active_sheet.cell(r, 54).value,
        day_50=active_sheet.cell(r, 55).value,
        day_51=active_sheet.cell(r, 56).value,
        day_52=active_sheet.cell(r, 57).value,
        day_53=active_sheet.cell(r, 58).value,
        day_54=active_sheet.cell(r, 59).value,
        day_55=active_sheet.cell(r, 60).value,
        day_56=active_sheet.cell(r, 61).value,
        Standing_Capacity=active_sheet.cell(r, 62).value
        )

    return render(request, 'RUser/Add_DataSet_Details.html', {"excel_data": excel_data})


def Register1(request):

    if request.method == "POST":
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        phoneno = request.POST.get('phoneno')
        country = request.POST.get('country')
        state = request.POST.get('state')
        city = request.POST.get('city')
        ClientRegister_Model.objects.create(username=username, email=email, password=password, phoneno=phoneno,
                                            country=country, state=state, city=city)

        return render(request, 'RUser/Register1.html')
    else:

        return render(request,'RUser/Register1.html')


def ViewYourProfile(request):
    userid = request.session['userid']
    obj = ClientRegister_Model.objects.get(id= userid)
    return render(request,'RUser/ViewYourProfile.html',{'object':obj})


def Search_PassengerFlow_DataSets(request):
    if request.method == "POST":
        kword = request.POST.get('keyword')
        print(kword)
        obj = bus_capacity_model.objects.all().filter(names__contains=kword)
        obj1 = bus_capacity_model.objects.get(names__contains=kword)

        day_1 = (obj1.day_1)
        day_2 = (obj1.day_2)
        day_3 = (obj1.day_3)
        day_4 = (obj1.day_4)
        day_5 = (obj1.day_5)
        day_6 = (obj1.day_6)
        day_7 = (obj1.day_7)
        day_8 = (obj1.day_8)
        day_9 = (obj1.day_9)
        day_10 = (obj1.day_10)
        day_11 = (obj1.day_11)
        day_12 = (obj1.day_12)
        day_13 = (obj1.day_13)
        day_14 = (obj1.day_14)
        day_15 = (obj1.day_15)
        day_16 = (obj1.day_16)
        day_17 = (obj1.day_17)
        day_18 = (obj1.day_18)
        day_19 = (obj1.day_19)
        day_20 = (obj1.day_20)
        day_21 = (obj1.day_21)
        day_22 = (obj1.day_22)
        day_23 = (obj1.day_23)
        day_24 = (obj1.day_24)
        day_25 = (obj1.day_25)
        day_26 = (obj1.day_26)
        day_27 = (obj1.day_27)
        day_28 = (obj1.day_28)
        day_29 = (obj1.day_29)
        day_30 = (obj1.day_30)
        day_31 = (obj1.day_31)
        day_32 = (obj1.day_32)
        day_33 = (obj1.day_33)
        day_34 = (obj1.day_34)
        day_35 = (obj1.day_35)
        day_36 = (obj1.day_36)
        day_37 = (obj1.day_37)
        day_38 = (obj1.day_38)
        day_39 = (obj1.day_39)
        day_40 = (obj1.day_40)
        day_41 = (obj1.day_41)
        day_42 = (obj1.day_42)
        day_43 = (obj1.day_43)
        day_44 = (obj1.day_44)
        day_45 = (obj1.day_45)
        day_46 = (obj1.day_46)
        day_47 = (obj1.day_47)
        day_48 = (obj1.day_48)
        day_49 = (obj1.day_49)
        day_50 = (obj1.day_50)
        day_51 = (obj1.day_51)
        day_52 = (obj1.day_52)
        day_53 = (obj1.day_53)
        day_54 = (obj1.day_54)
        day_55 = (obj1.day_55)
        day_56 = (obj1.day_56)
        Standing_Capacity = (obj1.Standing_Capacity)


        data = [[1,day_1],[2,day_2],[3,day_3],[4,day_4],[5,day_5],[6,day_6],[7,day_7],[8,day_8],[9,day_9],[10,day_10],[11,day_11],[12,day_12],[13,day_13],[14,day_14],[15,day_15],[16,day_16],[17,day_17],[18,day_18],[19,day_19],[20,day_20],[21,day_21],[22,day_22],[23,day_23],[24,day_24],[25,day_25],[26,day_26],[27,day_27],[28,day_28],[29,day_29],[30,day_30],[31,day_31],[32,day_32],[33,day_33],[34,day_34],[35,day_35],[36,day_36],[37,day_37],[38,day_38],[39,day_39],[40,day_40],[41,day_41],[42,day_42],[43,day_43],[44,day_44],[45,day_45],[46,day_46],[47,day_47],[48,day_48],[49,day_49],[50,day_50],[51,day_51],[52,day_52],[53,day_53],[54,day_54],[55,day_55],[56,day_56]]
        X = np.array(data)[:, 0].reshape(-1, 1)
        y = np.array(data)[:, 1].reshape(-1, 1)
        print("X=")
        print(X)
        print("y=")
        print(y)
        to_predict_x = [57]
        to_predict_x = np.array(to_predict_x).reshape(-1, 1)
        regsr = LinearRegression()
        regsr.fit(X, y)
        predicted_y = regsr.predict(to_predict_x)
        m = regsr.coef_
        c = regsr.intercept_
        print("Predicted y:\n", predicted_y)
        print("slope (m): ", m)
        print("y-intercept (c): ", c)

        if predicted_y > 1:
            p="THERE MAY BE A RUSH"
        elif predicted_y == 1:
            p="THE BUS MAY BE FULL"
        else:
            p="THERE IS NO RUSH"

        return render(request, 'RUser/Search_PassengerFlow_DataSets.html',{'objs': obj,'ratio':str(predicted_y)+" "+p})
    return render(request, 'RUser/Search_PassengerFlow_DataSets.html')


def View_Bus_Capacity_DataSetDetails(request):
    obj =bus_capacity_model.objects.all()
    return render(request, 'RUser/View_Bus_Capacity_DataSetDetails.html', {'list_objects': obj})


def ratings(request,pk):
    vott1, vott, neg = 0, 0, 0
    objs = bus_capacity_model.objects.get(id=pk)
    unid = objs.id
    vot_count = bus_capacity_model.objects.all().filter(id=unid)
    for t in vot_count:
        vott = t.ratings
        vott1 = vott + 1
        obj = get_object_or_404(bus_capacity_model, id=unid)
        obj.ratings = vott1
        obj.save(update_fields=["ratings"])
        return redirect('Add_DataSet_Details')

    return render(request,'RUser/ratings.html',{'objs':vott1})



